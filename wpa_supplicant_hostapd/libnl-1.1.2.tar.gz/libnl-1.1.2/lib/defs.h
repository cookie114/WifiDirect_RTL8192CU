/* lib/defs.h.  Generated from defs.h.in by configure.  */
/* lib/defs.h.in.  Generated from configure.in by autoheader.  */

/* Define to 1 to disable pthreads */
/* #undef DISABLE_PTHREADS */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "tgraf@suug.ch"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libnl"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libnl 1.1.2"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libnl"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.1.2"

/* verbose errors */
/* #undef VERBOSE_ERRORS */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif
